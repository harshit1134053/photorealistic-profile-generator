PROMPT_TEMPLATE = (
    "A photorealistic profile picture of a young Indian professional, wearing formal attire, "
    "with a neutral background, DSLR quality, soft lighting, ultra-detailed"
)
