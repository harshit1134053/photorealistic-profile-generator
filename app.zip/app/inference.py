from app.model import load_model
from datetime import datetime
import os

pipe = load_model()

def generate_profile_image(prompt: str) -> str:
    output = pipe(prompt, num_inference_steps=30, guidance_scale=7.5)
    image = output.images[0]

    os.makedirs("generated", exist_ok=True)
    timestamp = datetime.now().strftime("%Y%m%d%H%M%S")
    filepath = f"generated/profile_{timestamp}.png"
    image.save(filepath)

    return filepath
