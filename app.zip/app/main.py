from fastapi import FastAPI, UploadFile, Form
from app.inference import generate_profile_image

app = FastAPI()

@app.get("/")
def read_root():
    return {"message": "Photorealistic Profile Generator API is live!"}

@app.post("/generate/")
async def generate_image(prompt: str = Form(...)):
    image_path = generate_profile_image(prompt)
    return {"image_path": image_path}
