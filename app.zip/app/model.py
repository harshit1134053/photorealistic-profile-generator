from diffusers import StableDiffusionPipeline
import torch

def load_model():
    model_id = "stabilityai/stable-diffusion-2-1"
    lora_path = "./lora_weights"

    pipe = StableDiffusionPipeline.from_pretrained(
        model_id,
        torch_dtype=torch.float16,
        safety_checker=None,
        revision="fp16"
    ).to("cuda")

    pipe.load_lora_weights(lora_path)
    pipe.fuse_lora()
    pipe.enable_xformers_memory_efficient_attention()

    return pipe
